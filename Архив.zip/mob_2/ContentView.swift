import SwiftUI

struct ContentView: View {
    @State private var selectedTab: String = "home" // Хранит текущую выбранную вкладку

    var body: some View {
        NavigationView {
            VStack {
                switch selectedTab {
                case "home":
                    HomeFeedView()
                case "search":
                    SearchView()
                case "add":
                    AddPostView()
                case "notifications":
                    NotificationsView()
                case "profile":
                    ProfileView()
                default:
                    HomeFeedView()
                }
                

                HStack {
                    Button(action: {
                        selectedTab = "home"
                    }) {
                        Image(systemName: "house.fill")
                            .foregroundColor(selectedTab == "home" ? .blue : .black)
                    }

                    Spacer()

                    Button(action: {
                        selectedTab = "search"
                    }) {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(selectedTab == "search" ? .blue : .black)
                    }

                    Spacer()

                    Button(action: {
                        selectedTab = "add"
                    }) {
                        Image(systemName: "plus.app")
                            .foregroundColor(selectedTab == "add" ? .blue : .black)
                    }

                    Spacer()

                    Button(action: {
                        selectedTab = "notifications"
                    }) {
                        Image(systemName: "bell")
                            .foregroundColor(selectedTab == "notifications" ? .blue : .black)
                    }

                    Spacer()

                    Button(action: {
                        selectedTab = "profile"
                    }) {
                        Image(systemName: "person")
                            .foregroundColor(selectedTab == "profile" ? .blue : .black)
                    }
                }
                .padding(.horizontal)
                .padding(.vertical, 10)
                .background(Color.white)
                .shadow(radius: 2)
            }
            .navigationBarHidden(true) // Скрыть стандартный навбар
        }
    }
}
