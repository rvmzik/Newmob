import SwiftUI

struct Post: Identifiable {
    var id = UUID()
    var username: String
    var image: String
    var caption: String
    var likes: Int
}

struct Story: Identifiable {
    var id = UUID()
    var image: String
    var username: String
}

struct HomeFeedView: View {
    let posts = [
        Post(username: "sukuna", image: "avatar", caption: "Hello", likes: 6),
        Post(username: "gojo", image: "image1", caption: "Mobile application", likes: 7)
    ]
    
    let stories = [
        Story(image: "image1", username: "Ramazan"),
        Story(image: "yuji", username: "yuji"),
        Story(image: "gojo", username: "gojo"),
        Story(image: "sukuna", username: "sukuna"),
        Story(image: "mem1", username: "cat"),
    ]
    
    var body: some View {
        NavigationView {
            VStack {
                HStack {
                    Image("InstagramLogo")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 140, height: 70)
                        .padding(.leading, 10)
                    
                    Spacer()
                    NavigationLink(destination: NotificationsView()) {
                        Image("notifications")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 90, height: 80)
                            .padding(.trailing, 10)
                            .foregroundColor(.black)
                    }
                }
                .padding(.top, 10)

                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 15) {
                        ForEach(stories) { story in
                            VStack {
                                Image(story.image)
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: 70, height: 70)
                                    .clipShape(Circle())
                                    .overlay(Circle().stroke(Color.gray, lineWidth: 2))

                                Text(story.username)
                                    .font(.caption)
                                    .lineLimit(1)
                            }
                            .frame(width: 80)
                        }
                    }
                    .padding(.horizontal, 10)
                }
                .padding(.vertical, 10)
                
                Divider()

   
                List(posts) { post in
                    VStack(alignment: .leading) {
                        Text(post.username)
                            .font(.headline)

                        Image(post.image)
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: UIScreen.main.bounds.width - 40, height: 300)
                            .clipped()

                        Text(post.caption)
                            .font(.subheadline)
                            .padding(.top, 5)

                        Text("Likes: \(post.likes)")
                            .font(.footnote)
                    }
                    .padding(.bottom, 10)
                }
                .listStyle(PlainListStyle())
                .background(Color.white)
                .edgesIgnoringSafeArea(.bottom)
            }
            .navigationBarHidden(true)
        }
    }
}


struct NotificationsView: View {
    let notifications = ["One comment to post", "One like to post"]

    var body: some View {
        List(notifications, id: \.self) { notification in
            Text(notification)
        }
        .navigationTitle("Notifications")
    }
}
