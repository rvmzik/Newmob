//
//  SearchView.swift
//  mob_2
//
//  Created by Рамазан Алиев on 18.10.2024.
//

import SwiftUI

struct SearchResult: Identifiable {
    var id = UUID()
    var username: String
    var image: String
}

struct SearchView: View {
    let results = [
        SearchResult(username: "Yuji", image: "yuji"),
        SearchResult(username: "Sukuna", image: "sukuna"),
        SearchResult(username: "Gojo", image: "gojo")
    ]
    
    @State private var searchText = ""

    var body: some View {
        VStack {
            // Поле поиска
            SearchBar(text: $searchText)
                .padding()

            List(results.filter { searchText.isEmpty ? true : $0.username.contains(searchText) }) { result in
                HStack {
                    Image(result.image)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 40, height: 40)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.gray, lineWidth: 1))
                    Text(result.username)
                        .font(.headline)
                }
            }
            .listStyle(PlainListStyle())
        }
        .navigationTitle("Search")
        .navigationBarBackButtonHidden(true)
    }
}

struct SearchBar: View {
    @Binding var text: String

    var body: some View {
        TextField("Search", text: $text)
            .padding(10)
            .background(Color(.systemGray6))
            .cornerRadius(10)
            .padding(.horizontal)
    }
}

