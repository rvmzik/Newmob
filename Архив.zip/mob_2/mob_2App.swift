//
//  mob_2App.swift
//  mob_2
//
//  Created by Рамазан Алиев on 18.10.2024.
//

import SwiftUI

@main
struct mob_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
