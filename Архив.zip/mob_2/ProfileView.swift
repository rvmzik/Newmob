import SwiftUI

struct ProfileView: View {
    let userName: String = "Ramazan"
    let bio: String = "KBTU - Software Engineering"
    
    let posts: [String] = [
        "image1", "avatar", "mem1",
        "mem3", "mem4", "mem6",
        "images (2)", "mem5", "mem7"
    ]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading) {
                HStack(alignment: .top) {
                    Image("CJ")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 100, height: 100)
                        .clipShape(Circle())
                        .padding(.top, 20)
                        .padding(.leading, 20)

                    Spacer()
                    VStack {
                        Text("\(posts.count)")
                            .font(.headline)
                            .font(.system(size: 14))
                            .padding(.top, 30)
                        Text("Posts")
                            .font(.subheadline)
                            .font(.system(size: 12))
                    }
                    Spacer()
                    VStack {
                        Text("7")
                            .font(.headline)
                            .font(.system(size: 14))
                            .padding(.top, 30)
                        Text("Followers")
                            .font(.subheadline)
                            .font(.system(size: 12))
                    }
                    Spacer()
                    VStack {
                        Text("7")
                            .font(.headline)
                            .font(.system(size: 14))
                            .padding(.top, 30)
                        Text("Following")
                            .font(.subheadline)
                            .font(.system(size: 12))
                    }
                }
                .padding(.top, 10)
                .padding(.horizontal, 20) // Отступы для выравнивания

                // Имя пользователя и биография
                VStack(alignment: .leading) {
                    Text(userName)
                        .font(.title)
                        .fontWeight(.bold)
                        .padding(.top, 10) // Отступ сверху
                    Text(bio)
                        .font(.subheadline)
                        .foregroundColor(.gray)
                        .padding(.top, 1) // Добавляем небольшой отступ между именем и биографией
                }
                .padding(.leading, 20) // Отступ слева для выравнивания

                let columns = Array(repeating: GridItem(.fixed(100), spacing: 10), count: 3)

                LazyVGrid(columns: columns, spacing: 10) {
                    ForEach(posts, id: \.self) { post in
                        Image(post)
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 100, height: 100)
                            .clipped()
                    }
                }
                .padding()
            }
        }
        .navigationTitle("Profile")
        .navigationBarTitleDisplayMode(.inline)  заголовка
    }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView()
    }
}
