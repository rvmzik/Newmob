//
//  AddPostView.swift
//  mob_2
//
//  Created by Рамазан Алиев on 18.10.2024.
//


import SwiftUI

struct AddPostView: View {
    @State private var caption: String = ""
    @State private var isImageSelected: Bool = false

    var body: some View {
        VStack {
            Text("New Post")
                .font(.title)
                .fontWeight(.bold)
                .padding(.top, 20)
            

            Button(action: {
                isImageSelected.toggle()
            }) {
                Text(isImageSelected ? "Image Added" : "Add Image")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(isImageSelected ? Color.yellow : Color.blue)
                    .cornerRadius(10)
            }
            .padding(.horizontal)
            .padding(.top, 20)
            

            TextField("Enter caption...", text: $caption)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding(.horizontal)
                .padding(.top, 10)
            
            Spacer()
            
            Button(action: {
                print("Button tapped")
            }) {
                Text("Post")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            .padding(.horizontal)
            .padding(.bottom, 20)
        }
    }
}

struct AddPostView_Previews: PreviewProvider {
    static var previews: some View {
        AddPostView()
    }
}
